import java.util.Arrays;
import java.util.Scanner;

public class Guibing {
    public static void main(String[] args) {
        System.out.println("从键盘上输入数字并用空格隔开");
        Scanner sc = new Scanner(System.in);
        String inputString = sc.nextLine();//将键盘上的输入作为输入流传入
        String stringArray[] = inputString.split(" ");//用空格分割并传入字符数组
        int[] num = new int[stringArray.length];//创建所需的整数数组
        for (int i = 0; i < stringArray.length; i++) {
            num[i] = Integer.parseInt(stringArray[i]);//将字符数组转为整数数组
        }
            Guibing a = new Guibing();//通过实例化引用方法
            int[] newnum = a.sort(num);
            for (int x : newnum) {
                System.out.println(x);//逐个打印整数数组中的内容
            }

    }

    int[] sort(int[] nums){
        if(nums.length == 1){
            return nums;//当只有一个元素时本身就是有序的，输出这个个有序数组
        }
            int middle = (int)Math.floor(nums.length /2);//Math.floor()函数返回小于等于一个给定数字的最大整数
            int[]left = Arrays.copyOfRange(nums,0,middle);//创建一个新的数组，包含原数组中从第一项开始，到第middle项结束
            int[]right = Arrays.copyOfRange(nums,middle,nums.length);//包含原数组中的第middle+1项到最后一项

            int[] newleft = sort(left);//无限递归二分直至划分为单个元素数组
            int[] newright = sort(right);
            return merge(newleft,newright);//再逐层比较并最终合成一个新的有序数组

    }
    protected int[] merge(int[]left,int[]right){//将两个有序数组合成一个有序数组
        int[]result = new int[left.length + right.length];//创建新数组的内存空间，使之大小等于传入的两个二分数组大小之和
        int i = 0;
        while(left.length>0 && right.length>0){//在两数组长度都不为零时逐个比较
            if(left[0]<=right[0]){
                result[i++] = left[0];//先取i再自增，将较小的数放入新数组的下一位中
                left = Arrays.copyOfRange(left, 1, left.length);//移动指针，使其指向须比较的下一位
            } else {
                result[i++] = right[0];//右指针较小时同理
                right = Arrays.copyOfRange(right, 1, right.length);
            }
        }
        //当有一个数组被整理完后，将剩下数组的剩下项全部复制到新数组中
        while (left.length > 0) {
            result[i++] = left[0];
            left = Arrays.copyOfRange(left, 1, left.length);
        }

        while (right.length > 0) {
            result[i++] = right[0];
            right = Arrays.copyOfRange(right, 1, right.length);
        }

        return result;//返回整理好的有序数组
    }
}
