import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        int n;
        Scanner in = new Scanner(System.in);
        n = in.nextInt();
        Main a = new Main();
        a.hanoi(n,'a','b','c');
    }
    void hanoi(int n,char A,char B,char C){
        if(n==1){
            System.out.println(A+"->"+C);
        }
        else{
            hanoi(n-1,A,C,B);
            System.out.println(A+"->"+C);
            hanoi(n-1,B,A,C);
        }
    }
}
