import java.util.*;

public class Main {

    private static String N1;//便于方法调用
    private static List<Person> persons;

    public static void main(String[] args) {
        System.out.println("从键盘上输入数字并用空格隔开");
        Scanner sc1 = new Scanner(System.in);
        String inputString = sc1.nextLine();//将键盘上的输入作为输入流传入
        String stringArray1[] = inputString.split(" ");//用空格分割并传入字符数组
        int[] num1= new int[stringArray1.length];//创建所需的整数数组
        for (int i = 0; i < stringArray1.length; i++) {
            num1[i] = Integer.parseInt(stringArray1[i]);//将字符数组转为整数数组
        }
        int N = num1[0];
        N1 = String.valueOf(2*N);
        int R = num1[1];
        int Q = num1[2];

        int[] num2;
        num2 = print();
        //数组num2中存储着初始分数
        int[] num3;
        num3 = print();
        //数组num3中存储着实力值

        persons = new ArrayList<>();//创建列表便于排序

        int i = 1;
        while(i<= 2*N){
            Person person = new Person(i,num2[i-1],num3[i-1]);//将每个选手的数据导入
            i++;
            persons.add(person);//将选手们的数据导入列表
        }
        sort();//调用方法对列表排序
        Person[] per = persons.toArray(new Person[2*N]);//将所有选手按列表顺序放入对象数组


    int a = 1;
    while (a<=R){//共进行R轮比赛
        int n=1;
        while(n<= (2*N-2)){
            if(game(per[2*n-1],per[2*n])){//两两比赛
                per[2*n-1].setRank(per[2*n-1].rank+1);//对数组进行修改
                persons.set(2*n-1,per[2*n-1]);//对列表进行修改
            }else{
                per[2*n].setRank(per[2*n].rank+1);
                persons.set(2*n,per[2*n]);
            }
            n++;
            n++;
        }
        sort();//每次比赛后重新排序

        a++;
        }
        System.out.println(per[Q-1].getNumber());//输出排名为Q的选手编号
    }



    public static boolean game(Person p1, Person p2){
        if(p1.getPower()>p2.getPower()){
            return true;//p1赢了
        }else{
            return false;//p2赢了
        }
    }
    public static int[] print(){
        System.out.println("从键盘上输入"+ Main.N1+"个数字并用空格隔开");
        Scanner sc2 = new Scanner(System.in);
        String inputString2 = sc2.nextLine();//将键盘上的输入作为输入流传入
        String stringArray2[] = inputString2.split(" ");//用空格分割并传入字符数组
        int[] num = new int[stringArray2.length];//创建所需的整数数组
        for (int i = 0; i < stringArray2.length; i++) {
            num[i] = Integer.parseInt(stringArray2[i]);//将字符数组转为整数数组
        }
        return num;
    }
    public static void sort(){
        Collections.sort(Main.persons,new Comparator<Person>(){
            @Override
            public int compare(Person p1,Person p2){
                if(p2.rank != p1.rank){
                    return p2.rank-p1.rank;
                }else{
                    return p2.getNumber() - p1.getNumber();
                }

            }
        });//对列表进行排序，按照rank降序排列，若rank相同，编号低的靠前
    }
}
