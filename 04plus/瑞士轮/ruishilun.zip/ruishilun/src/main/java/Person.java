import java.util.Collections;
import java.util.Comparator;

public class Person {
    private int number;
    int rank;
    private int power;
    public Person(int number,int rank,int power){
        this.number = number;
        this.rank = rank;
        this.power = power;
    }
    public int getRank(){
        return rank;
    }
    public int getNumber(){
        return number;
    }
    public int getPower(){
        return power;
    }
    public void setNumber(int number){
        this.number = number;

    }
    public void setRank(int rank){
        this.rank = rank;

    }

    public void setPower(int power) {
        this.power = power;
    }

}
