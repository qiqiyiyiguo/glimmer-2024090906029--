import java.util.Random;

public class Dish {
    protected  String name;
    protected  double price;
    static int count = 0;

    public void profile(String profile) {
        java.lang.System.out.println(profile);
    }

    public Dish(String name, double price){
        int number;
        this.name = name;
        this.price = price;
        count = count + 1;
        number = count;
    }

}