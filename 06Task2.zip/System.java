import java.io.PrintStream;
import java.util.List;
import java.util.ArrayList;

public class System {
    ArrayList<String> arrayList= new ArrayList<>();//这一句为创建一个list？
    private static int number = 1;

    public void manageOrder(List<Order> dishes){
        //这个list没有作用？

        //创建对象以调用非static类中的方法
        Dish_1 one = new Dish_1("a",1);
        boolean a = one.check();

        Dish_2 two = new Dish_2("b",2);
        boolean b = two.check();

        //同时为真才继续运行
        if(a && b){
            one.cook();
            two.cook();
            //输出编号
            java.lang.System.out.println(number);
        }
        //有一假取消订单
        else{
            java.lang.System.out.println("取消订单");
        }
        //编号递增
        number++;
    }
}
