//空文件异常
public class EmptyFileException extends Exception {

    private String message;

    public EmptyFileException(String message){
        super(message);
        this.message = message;
    }

}