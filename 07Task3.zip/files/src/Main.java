import java.io.*;

public class Main {
    //创建对象并导入文件路径
    static File file = new File("E:\\glimmer\\data.txt");



    public static void main(String[] args) throws IOException, EmptyFileException {
        String line;
        int number;
        int addition = 0;
        int count = 0;

        //文件不存在时抛出异常
        if(!file.exists()){
            System.out.println("文件不存在");
            throw new FileNotFoundException("FileNotFoundException");
        }
        //文件为空时抛出异常
        if(0 == file.length()){
            System.out.println("文件为空");
            throw new EmptyFileException("EmptyFileException");

        }


        try (BufferedReader reader = new BufferedReader(new FileReader(file))){
            //按行读取文件

            while ((line = reader.readLine()) != null){
                //将读取到的内容转化为数字
                try{
                    number = Integer.parseInt(line);
                }catch(NumberFormatException e){
                    //文件中包含无法解析为整数的内容时提示错误
                    System.out.println("读取到的内容格式错误");
                    throw new NumberFormatException("NumberFormatException");
                }finally {
                    System.out.println("In finally");
                }
                //求和
                addition += number;
                //计数
                count ++;
            }


        }finally {
            System.out.println("In finally");
        }

        double average;
        average = (double) addition / (double) count;
        System.out.println("平均值为" + average);


    }




}