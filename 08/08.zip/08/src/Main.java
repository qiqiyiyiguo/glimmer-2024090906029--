import java.text.Collator;
import java.util.*;
import java.util.Comparator;

public class Main {
    public static void main(String[] args) {
    Main a = new Main();
    a.compareTest();


    }

    public void compareTest() {
        List<Song> list = new ArrayList<>();
        list.add(new Song("qndsehdhj","ncisuhdkhv",237));
        list.add(new Song("djinncs","jiad",38937));
        list.add(new Song("cilaiif","efjjbh",129));
        list.add(new Song("uisbhb","bwiuhdd",91));
        list.add(new Song("hsjxniuuuhzxh","iouixb",9772));


        Collections.sort(list,new Comparator<Song>() {

            @Override
            public int compare(Song o1, Song o2) {
                String a = o1.title;
                String b = o2.title;
                return Collator.getInstance(Locale.UK).compare(a,b);
            }
        });

        for (Song s:list){

            System.out.println(s.print());
        }



    }
}


