import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class MockSongs {

    public static List<String> getSongStrings(){
        List<String> songs = new ArrayList<>();
        //模拟将要处理的列表
        songs.add("sunrise");
        songs.add("noprice");
        songs.add("thanks");
        songs.add("$100");
        songs.add("havana");
        songs.add("114514");

        songs.sort(Comparator.naturalOrder());
        return songs;
    }
}