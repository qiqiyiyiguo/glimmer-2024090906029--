public class Song {
    String title;
    private String artist;
    private int bpm;

    public Song (String title,String artist,int bpm){
        this.title = title;
        this.artist = artist;
        this.bpm = bpm;
    }


    public  String print(){
        return"Song:\ntitle=" + title + "\n"+"artist="+artist+"\nbpm="+bpm+"\n";
    }



}


