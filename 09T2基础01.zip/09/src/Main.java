import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import  java.io.*;
import java.io.Serializable;


public class Main {
    public static void main(String[] args) {
        Songs s = new Songs();
        s.printsongs();
        s.print();



        File f = new File("song.txt");
        FileOutputStream fop;
        try {
            fop = new FileOutputStream(f);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        OutputStreamWriter writer;
        try {
            writer = new OutputStreamWriter(fop,"UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }

        try {
            for(Song song: s.songs) {
                writer.append(song.toString());
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
}