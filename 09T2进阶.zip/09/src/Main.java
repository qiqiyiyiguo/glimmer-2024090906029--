import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import  java.io.*;
import java.io.Serializable;


public class Main {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        Songs s = new Songs();
        s.printsongs();
        s.print();

        File file = new File("newsong.txt");
        file.createNewFile();

        try {
            FileWriter writer = new FileWriter(file);
            writer.write(s.songs.toString());
            writer.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        FileReader fr = new FileReader(file);
        char[] a = new char[5000];
        fr.read(a);
        for (char c : a)
            System.out.print(c);
        fr.close();


    }
}