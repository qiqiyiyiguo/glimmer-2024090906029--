import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class SimpleChatServer {
    private final List<PrintWriter> clientWriters = new ArrayList<>();
    public String message;
    public static void main(String[] args) throws IOException {
        new SimpleChatServer().go();


    }



    public void go() throws IOException {
        while (true){
            ServerSocket server = new ServerSocket(8888);
            System.out.println("启动服务器....");
            Socket socket = server.accept();
            System.out.println("客户端:" + server.getInetAddress().getLocalHost() + "已连接到服务器");
            Boolean close = isServerClose(socket);
            while (!close){
                BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                //读取客户端发送来的消息
                message = br.readLine();
                tellEveryone();
                close = isServerClose(socket);
            }
            server.close();

        }





    }

    private void tellEveryone() {
        System.out.println("客户端："+ message);
    }

    public class ClientHandler implements Runnable {

        public void run() {
            //运行函数
        }
    }

    public Boolean isServerClose(Socket socket) {
        try {
            socket.sendUrgentData(0xFF);//发送1个字节的紧急数据，默认情况下，服务器端没有开启紧急数据处理，不影响正常通信
            return false;
        } catch (Exception se) {
            return true;
        }
    }
}