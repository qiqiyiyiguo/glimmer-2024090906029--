import java.io.*;
import java.net.Socket;
import java.util.Objects;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class SimpleChatClientA {
    public static final String QUIT = "quit";
    static Socket socket;
    public static void main(String[] args) throws IOException {
        socket = new Socket("127.0.0.1", 8888);

        Receive receive = new Receive(socket);
        Thread re = new Thread(receive);
        re.start();

        Send send = new Send(socket);
        Thread se = new Thread(send);
        se.start();


    }
}

    class Receive implements Runnable {
        InputStreamReader inputStream;

        public Receive(Socket socket) throws IOException {
            inputStream = new InputStreamReader(socket.getInputStream()) {
            };
        }

        @Override
        public void run() {
           while (true){
                BufferedReader br = new BufferedReader(inputStream);
                String message = null;
                try {
                    message = br.readLine();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                System.out.println(message);

            }
        }
    }

    class Send implements Runnable {
        public static String QUIT = "quit";
        String mess;
        DataOutputStream outputStream;

        public Send(Socket socket) throws IOException{
            outputStream = new DataOutputStream(socket.getOutputStream());
        }
        @Override
        public void run() {
            do {
                BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
                try {
                    mess = br.readLine();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }

                PrintWriter writer = new PrintWriter(new OutputStreamWriter(outputStream));
                writer.write(mess + "\n");
                writer.flush();
                System.out.println("信息已上传至服务器");
            } while (!Objects.equals(mess, QUIT));
            try {
                SimpleChatClientA.socket.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }


    }
