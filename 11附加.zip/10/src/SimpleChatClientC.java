import java.io.*;
import java.net.Socket;
import java.util.Objects;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class SimpleChatClientC {
    public static final String QUIT = "quit";
    static Socket socket;
    public static void main(String[] args) throws IOException {
        socket = new Socket("127.0.0.1", 8890);

        ReceiveC receive = new ReceiveC(socket);
        Thread re = new Thread(receive);
        re.start();

        SendC send = new SendC(socket);
        Thread se = new Thread(send);
        se.start();


    }
}

class ReceiveC implements Runnable {
    InputStreamReader inputStream;

    public ReceiveC(Socket socket) throws IOException {
        inputStream = new InputStreamReader(socket.getInputStream()) {
        };
    }

    @Override
    public void run() {
        while (true){
            BufferedReader br = new BufferedReader(inputStream);
            String message = null;
            try {
                message = br.readLine();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            System.out.println(message);

        }
    }


}

class SendC implements Runnable {
    public static String QUIT = "quit";
    String mess;
    DataOutputStream outputStream;

    public SendC(Socket socket) throws IOException{
        outputStream = new DataOutputStream(socket.getOutputStream());
    }
    @Override
    public void run() {
        do {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            try {
                mess = br.readLine();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            PrintWriter writer = new PrintWriter(new OutputStreamWriter(outputStream));
            writer.write(mess + "\n");
            writer.flush();
            System.out.println("信息已上传至服务器");
        } while (!Objects.equals(mess, QUIT));
        try {
            SimpleChatClientA.socket.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public Boolean isServerClose(Socket socket) {
        try {
            socket.sendUrgentData(0xFF);//发送1个字节的紧急数据，默认情况下，服务器端没有开启紧急数据处理，不影响正常通信
            return false;
        } catch (Exception se) {
            return true;
        }
    }

}
