import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Objects;
import java.util.Vector;


public class SimpleChatServer {
    private final List<PrintWriter> clientWriters = new ArrayList<>();


static Socket socketA;
    static Socket socketB;
    static Socket socketC;
    public void main(String[] args) throws IOException {
        ServerSocket serverSocketA = new ServerSocket(8888);
        socketA = serverSocketA.accept();

        ServerSocket serverSocketB = new ServerSocket(8889);
        socketB = serverSocketB.accept();

        ServerSocket serverSocketC = new ServerSocket(8890);
        socketC = serverSocketC.accept();

        ClientHandlerA clinentA = new ClientHandlerA(socketA);
        Thread a = new Thread(clinentA);
        a.start();

        ClientHandlerB clinentB = new ClientHandlerB(socketB);
        Thread b = new Thread(clinentB);
        b.start();

        ClientHandlerC clinentC = new ClientHandlerC(socketC);
        Thread c = new Thread(clinentC);
        c.start();

        HandlerA cliA = new HandlerA(socketA);
        Thread cla = new Thread(cliA);
        cla.start();

        HandlerB cliB = new HandlerB(socketB);
        Thread clb = new Thread(cliB);
        clb.start();

        HandlerC cliC = new HandlerC(socketC);
        Thread clc = new Thread(cliC);
        clc.start();

    }

}

class ClientHandlerA implements Runnable {
    InputStreamReader inputStream;
    DataOutputStream outputStreamA;
    DataOutputStream outputStreamB;
    DataOutputStream outputStreamC;

    public ClientHandlerA(Socket socket) throws IOException {
        inputStream = new InputStreamReader(socket.getInputStream()) {
        };
    }

    Boolean close = isServerClose(SimpleChatServer.socketA);

    @Override
    public void run() {
        while (!close) {
            BufferedReader br = new BufferedReader(inputStream);
            try {
                outputStreamA = new DataOutputStream(SimpleChatServer.socketA.getOutputStream());
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            try {
                outputStreamB = new DataOutputStream(SimpleChatServer.socketB.getOutputStream());
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            try {
                outputStreamC = new DataOutputStream(SimpleChatServer.socketC.getOutputStream());
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            String message = null;
            try {
                message = "客户端A:" + br.readLine();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            System.out.println(message);

            PrintWriter writerA = new PrintWriter(new OutputStreamWriter(outputStreamA));
            writerA.write(message + "\n");
            writerA.flush();
            System.out.println("信息已上传至客户端A");

            PrintWriter writerB = new PrintWriter(new OutputStreamWriter(outputStreamB));
            writerB.write(message + "\n");
            writerB.flush();
            System.out.println("信息已上传至客户端B");

            PrintWriter writerC = new PrintWriter(new OutputStreamWriter(outputStreamC));
            writerC.write(message + "\n");
            writerC.flush();
            System.out.println("信息已上传至客户端C");


            close = isServerClose(SimpleChatServer.socketA);
        }
        System.out.println("客户端A已关闭连接");
        try {
            SimpleChatServer.socketA.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


    public Boolean isServerClose(Socket socket) {
        try {
            socket.sendUrgentData(0xFF);//发送1个字节的紧急数据，默认情况下，服务器端没有开启紧急数据处理，不影响正常通信
            return false;
        } catch (Exception se) {
            return true;
        }
    }
}




class ClientHandlerB implements Runnable {
    InputStreamReader inputStream;
    DataOutputStream outputStreamA;
    DataOutputStream outputStreamB;
    DataOutputStream outputStreamC;

    public ClientHandlerB(Socket socket) throws IOException {
        inputStream = new InputStreamReader(socket.getInputStream()) {
        };
    }

    Boolean close = isServerClose(SimpleChatServer.socketB);

    @Override
    public void run() {
        while (!close) {
            BufferedReader br = new BufferedReader(inputStream);
            try {
                outputStreamA = new DataOutputStream(SimpleChatServer.socketA.getOutputStream());
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            try {
                outputStreamB = new DataOutputStream(SimpleChatServer.socketB.getOutputStream());
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            try {
                outputStreamC = new DataOutputStream(SimpleChatServer.socketC.getOutputStream());
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            String message = null;
            try {
                message = "客户端B:" + br.readLine();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            System.out.println(message);

            PrintWriter writerA = new PrintWriter(new OutputStreamWriter(outputStreamA));
            writerA.write(message + "\n");
            writerA.flush();
            System.out.println("信息已上传至客户端A");

            PrintWriter writerB = new PrintWriter(new OutputStreamWriter(outputStreamB));
            writerB.write(message + "\n");
            writerB.flush();
            System.out.println("信息已上传至客户端B");

            PrintWriter writerC = new PrintWriter(new OutputStreamWriter(outputStreamC));
            writerC.write(message + "\n");
            writerC.flush();
            System.out.println("信息已上传至客户端C");


            close = isServerClose(SimpleChatServer.socketB);
        }
        System.out.println("客户端B已关闭连接");
        try {
            SimpleChatServer.socketB.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


    public Boolean isServerClose(Socket socket) {
        try {
            socket.sendUrgentData(0xFF);//发送1个字节的紧急数据，默认情况下，服务器端没有开启紧急数据处理，不影响正常通信
            return false;
        } catch (Exception se) {
            return true;
        }
    }
}

class ClientHandlerC implements Runnable {
    InputStreamReader inputStream;
    DataOutputStream outputStreamA;
    DataOutputStream outputStreamB;
    DataOutputStream outputStreamC;

    public ClientHandlerC(Socket socket) throws IOException {
        inputStream = new InputStreamReader(socket.getInputStream()) {
        };
    }

    Boolean close = isServerClose(SimpleChatServer.socketC);

    @Override
    public void run() {
        while (!close) {
            BufferedReader br = new BufferedReader(inputStream);
            try {
                outputStreamA = new DataOutputStream(SimpleChatServer.socketA.getOutputStream());
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            try {
                outputStreamB = new DataOutputStream(SimpleChatServer.socketB.getOutputStream());
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            try {
                outputStreamC = new DataOutputStream(SimpleChatServer.socketC.getOutputStream());
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            String message = null;
            try {
                message = "客户端C:" + br.readLine();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            System.out.println(message);

            PrintWriter writerA = new PrintWriter(new OutputStreamWriter(outputStreamA));
            writerA.write(message + "\n");
            writerA.flush();
            System.out.println("信息已上传至客户端A");

            PrintWriter writerB = new PrintWriter(new OutputStreamWriter(outputStreamB));
            writerB.write(message + "\n");
            writerB.flush();
            System.out.println("信息已上传至客户端B");

            PrintWriter writerC = new PrintWriter(new OutputStreamWriter(outputStreamC));
            writerC.write(message + "\n");
            writerC.flush();
            System.out.println("信息已上传至客户端C");


            close = isServerClose(SimpleChatServer.socketC);
        }
        System.out.println("客户端C已关闭连接");
        try {
            SimpleChatServer.socketC.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


    public Boolean isServerClose(Socket socket) {
        try {
            socket.sendUrgentData(0xFF);//发送1个字节的紧急数据，默认情况下，服务器端没有开启紧急数据处理，不影响正常通信
            return false;
        } catch (Exception se) {
            return true;
        }
    }
}



class HandlerA implements Runnable {
    public static String QUIT = "quit";
    String mess;
    DataOutputStream outputStreamA;
    DataOutputStream outputStreamB;
    DataOutputStream outputStreamC;

    public HandlerA(Socket socket) throws IOException{
        try {
            outputStreamA = new DataOutputStream(SimpleChatServer.socketA.getOutputStream());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try {
            outputStreamB = new DataOutputStream(SimpleChatServer.socketB.getOutputStream());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try {
            outputStreamC = new DataOutputStream(SimpleChatServer.socketC.getOutputStream());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    @Override
    public void run() {

        do {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            try {
                mess = "服务器：" + br.readLine();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            PrintWriter writerA = new PrintWriter(new OutputStreamWriter(outputStreamA));
            writerA.write(mess + "\n");
            writerA.flush();
            System.out.println("信息已上传至客户端A");

            PrintWriter writerB = new PrintWriter(new OutputStreamWriter(outputStreamB));
            writerB.write(mess + "\n");
            writerB.flush();
            System.out.println("信息已上传至客户端B");

            PrintWriter writerC = new PrintWriter(new OutputStreamWriter(outputStreamC));
            writerC.write(mess + "\n");
            writerC.flush();
            System.out.println("信息已上传至客户端C");
        } while (!Objects.equals(mess, QUIT));
        try {
            SimpleChatServer.socketA.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}

class HandlerB implements Runnable {
    public static String QUIT = "quit";
    String mess;
    DataOutputStream outputStreamA;
    DataOutputStream outputStreamB;
    DataOutputStream outputStreamC;

    public HandlerB(Socket socket) throws IOException{
        try {
            outputStreamA = new DataOutputStream(SimpleChatServer.socketA.getOutputStream());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try {
            outputStreamB = new DataOutputStream(SimpleChatServer.socketB.getOutputStream());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try {
            outputStreamC = new DataOutputStream(SimpleChatServer.socketC.getOutputStream());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    @Override
    public void run() {

        do {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            try {
                mess = "服务器：" + br.readLine();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            PrintWriter writerA = new PrintWriter(new OutputStreamWriter(outputStreamA));
            writerA.write(mess + "\n");
            writerA.flush();
            System.out.println("信息已上传至客户端A");

            PrintWriter writerB = new PrintWriter(new OutputStreamWriter(outputStreamB));
            writerB.write(mess + "\n");
            writerB.flush();
            System.out.println("信息已上传至客户端B");

            PrintWriter writerC = new PrintWriter(new OutputStreamWriter(outputStreamC));
            writerC.write(mess + "\n");
            writerC.flush();
            System.out.println("信息已上传至客户端C");
        } while (!Objects.equals(mess, QUIT));
        try {
            SimpleChatServer.socketB.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}

class HandlerC implements Runnable {
    public static String QUIT = "quit";
    String mess;
    DataOutputStream outputStreamA;
    DataOutputStream outputStreamB;
    DataOutputStream outputStreamC;

    public HandlerC(Socket socket) throws IOException{
        try {
            outputStreamA = new DataOutputStream(SimpleChatServer.socketA.getOutputStream());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try {
            outputStreamB = new DataOutputStream(SimpleChatServer.socketB.getOutputStream());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try {
            outputStreamC = new DataOutputStream(SimpleChatServer.socketC.getOutputStream());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    @Override
    public void run() {

        do {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            try {
                mess = "服务器：" + br.readLine();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            PrintWriter writerA = new PrintWriter(new OutputStreamWriter(outputStreamA));
            writerA.write(mess + "\n");
            writerA.flush();
            System.out.println("信息已上传至客户端A");

            PrintWriter writerB = new PrintWriter(new OutputStreamWriter(outputStreamB));
            writerB.write(mess + "\n");
            writerB.flush();
            System.out.println("信息已上传至客户端B");

            PrintWriter writerC = new PrintWriter(new OutputStreamWriter(outputStreamC));
            writerC.write(mess + "\n");
            writerC.flush();
            System.out.println("信息已上传至客户端C");
        } while (!Objects.equals(mess, QUIT));
        try {
            SimpleChatServer.socketC.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}

