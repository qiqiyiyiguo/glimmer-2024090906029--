import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Objects;



public class SimpleChatServer {
    private final List<PrintWriter> clientWriters = new ArrayList<>();


static Socket socket;
    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(8888);
        socket = serverSocket.accept();

        ClientHandler clinent = new ClientHandler(socket);
        Thread c = new Thread(clinent);
        c.start();

        Handler cli = new Handler(socket);
        Thread cl = new Thread(cli);
        cl.start();

    }

}

class ClientHandler implements Runnable {
    InputStreamReader inputStream;

    public ClientHandler(Socket socket) throws IOException {
        inputStream = new InputStreamReader(socket.getInputStream()) {
        };
    }
    Boolean close = isServerClose(SimpleChatServer.socket);
    @Override
    public void run() {
        while (!close) {
            BufferedReader br = new BufferedReader(inputStream);
            String message = null;
            try {
                message = br.readLine();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            System.out.println("客户端：" + message);
            close = isServerClose(SimpleChatServer.socket);
        }
        System.out.println("客户端已关闭连接");
        try {
            SimpleChatServer.socket.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


    public Boolean isServerClose(Socket socket) {
        try {
            socket.sendUrgentData(0xFF);//发送1个字节的紧急数据，默认情况下，服务器端没有开启紧急数据处理，不影响正常通信
            return false;
        } catch (Exception se) {
            return true;
        }
    }
}

class Handler implements Runnable {
    public static String QUIT = "quit";
    String mess;
    DataOutputStream outputStream;

    public Handler(Socket socket) throws IOException{
        outputStream = new DataOutputStream(socket.getOutputStream());
    }
    @Override
    public void run() {

        do {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            try {
                mess = br.readLine();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            PrintWriter writer = new PrintWriter(new OutputStreamWriter(outputStream));
            writer.write(mess + "\n");
            writer.flush();
            System.out.println("信息已上传至客户端");
        } while (!Objects.equals(mess, QUIT));
        try {
            SimpleChatServer.socket.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public Boolean isServerClose(Socket socket) {
        try {
            socket.sendUrgentData(0xFF);//发送1个字节的紧急数据，默认情况下，服务器端没有开启紧急数据处理，不影响正常通信
            return false;
        } catch (Exception se) {
            return true;
        }
    }

}


