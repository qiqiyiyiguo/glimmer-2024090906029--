import java.util.ArrayList;
import java.util.List;

public class Main {


    public static void main(String[] args) {

        ArrayList<Boolean> dishes= new ArrayList<>();
        dishes.add(Dish_1.check);
        dishes.add(Dish_2.check);


    }



}