public interface Order {
    public String cook = "";
    public void cook();
    public boolean check();
}
