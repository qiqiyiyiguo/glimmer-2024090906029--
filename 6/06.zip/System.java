import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;

public class System {

    private static String in;
    List<Integer> order = new ArrayList<>();

    public void order() {

        Scanner scanner = new Scanner(System.in);


        int orders;
        do {
            java.lang.System.out.println("红烧肉：1；烤鸭：2");
            java.lang.System.out.println("请输入你需要的菜品编号");
            int food = scanner.nextInt();
            order.add(food);
            java.lang.System.out.println("继续点单输入1，结束输入2");
            orders = scanner.nextInt();
        } while (orders == 1);




    }



    private static int number = 1;



    public void manageOrder(List<Order> dishes){
        //这个list是什么？似乎没有作用？

        Scanner scanner = new Scanner(System.in);
//判断顾客类型
        java.lang.System.out.println("二维码点单：1;小程序点单：2\n" + "请选择点单方式");
        int customer = scanner.nextInt();
       //二维码点单默认堂食
        if(customer == 1){
            TableCustomer table = new TableCustomer();
            table.Table();
        }
//微信点单选择是否堂食
        else if(customer == 2){
            WechatCustomer wechat = new WechatCustomer();
            if (wechat.isTakeout()){
                wechat.Takeout();
            }
            else{
                TableCustomer table = new TableCustomer();
                table.Table();
            }


        }





        //创建对象以调用非static类中的方法
        Dish_1 one = new Dish_1("a",1);
        boolean a = one.check();

        Dish_2 two = new Dish_2("b",2);
        boolean b = two.check();


//清单中只有1号菜时
        if (order.contains(1) && !order.contains(2)){
//对菜品一判定
            if(a){
                one.cook();
                java.lang.System.out.println(number);
            }

            else{
                java.lang.System.out.println("取消订单");
            }
            //编号递增
            number++;

        }
        //清单中只有二号菜时
        else if(!order.contains(1) && order.contains(2)){
            //对菜品二判定
            if(b){
                two.cook();
                java.lang.System.out.println(number);
            }

            else{
                java.lang.System.out.println("取消订单");
            }
            //编号递增
            number++;
        }
//清单中同时出现两种菜时
        else if (order.contains(1) && order.contains(2)){
            //同时为真才继续运行
            if(a && b){
                one.cook();
                two.cook();
                //输出编号
                java.lang.System.out.println(number);
            }
            //有一假取消订单
            else{
                java.lang.System.out.println("取消订单");
            }
            //编号递增
            number++;
        }
        else{
            java.lang.System.out.println("取消订单");
            number++;
        }

        }




}
