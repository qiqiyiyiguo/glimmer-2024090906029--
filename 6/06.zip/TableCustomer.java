import java.lang.System;

public class TableCustomer {
    public int tableId;//餐桌编号
    public void Table(){
        java.lang.System.out.println("菜品将会送至" + tableId +"号桌");
    }
}