public class WechatCustomer {
    public String address;//顾客地址
    public boolean takeout;//true代表该顾客是外卖，false代表该顾客是堂食

    public boolean isTakeout() {
        return takeout;
    }
    public void Takeout(){
        java.lang.System.out.println("菜品将会送至" + address);
    }

}