public class Song{
    private String title;
    private String artist;
    private String genre;
    private int year;
    private int timesPlayed;
    //	利用注解或者自己创建构造器和get方法

    public Song(String title,String artist,String genre,int year,int timesPlayed){
        this.title = title;
        this.artist = artist;
        this.genre = genre;
        this.year = year;
        this.timesPlayed = timesPlayed;

    }

    public String getTitle(){
        return title;
    }

    public  String getArtist(){
        return artist;
    }

    public String getGenre(){
        return genre;
    }

    public int getYear(){
        return year;
    }

    public int getTimesPlayed(){
        return timesPlayed;
    }

    public String print(){
        return"Song:\ntitle=" + title + "\n"+"artist="+artist+"\ngenre="+genre+"\nyear"+year+"\ntimesPlayed"+timesPlayed+"\n";
    }

    public Boolean getRock(){
        boolean exist;
        String genre = this.genre;
        if(genre.contains("Rock")){
            exist = true;
        }else if(genre.contains("rock")){
            exist = true;
        }else{
            exist = false;
        }
        return exist;
    }



}
