import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import  java.io.*;
import java.io.Serializable;


public class Main {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        Songs s = new Songs();
        s.printsongs();
        s.print();


        FileOutputStream f = new FileOutputStream("song.txt");
        ObjectOutputStream ss = new ObjectOutputStream(f);
        ss.writeObject(s.songs);
        ss.flush();




        FileInputStream in = new FileInputStream("song.txt");
        ObjectInputStream sss = new ObjectInputStream(in);

        List newsong = (List) sss.readObject(); //恢复对象;

        System.out.println(newsong);

    }
}